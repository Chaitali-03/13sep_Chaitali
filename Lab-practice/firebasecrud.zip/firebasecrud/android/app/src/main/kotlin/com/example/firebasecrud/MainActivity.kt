package com.example.firebasecrud

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
