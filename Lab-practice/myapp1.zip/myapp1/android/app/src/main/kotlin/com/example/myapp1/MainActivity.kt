package com.example.myapp1

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
