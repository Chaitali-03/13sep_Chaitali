package com.example.q_51

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
