package com.example.q_50

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
