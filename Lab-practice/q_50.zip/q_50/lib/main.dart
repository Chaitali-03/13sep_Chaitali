import 'package:flutter/material.dart';

void main()
{
  runApp(MaterialApp(home: MyApp(),debugShowCheckedModeBanner: false,));
}
class MyApp extends StatefulWidget {
  const MyApp({super.key});

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  TextEditingController number = TextEditingController();

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Reverse Number Example:"),backgroundColor: Colors.purple,),
      body: Column(
        children: [
          TextField(controller: number,
          decoration: InputDecoration(
              labelText: "Number:",
              hintText: "Enter more then 2 digit number",
              enabledBorder: OutlineInputBorder(
              borderSide: BorderSide(color: Colors.black),
              borderRadius: BorderRadius.circular(10)
          )),),
          SizedBox(height: 30),
          ElevatedButton(onPressed: (){
            reverse();
          }, child: Text("Click")),
        ],
      ),
    );
  }

  void reverse() {
    int? num = int.tryParse(number.text.toString());
    setState(() {
      int reverse=0;
      int remainder;
      while(num!=0)
      {
        remainder=(num!%10);
        reverse=reverse*10+remainder;
        num=(num!/10) as int?;
      }
      print("Reversed Number: $reverse");
    });
  }
}
