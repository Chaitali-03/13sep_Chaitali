class model
{
  late String image;

  model({
    required this.image,
});
}