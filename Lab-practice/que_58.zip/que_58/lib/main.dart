//58. Write a program you have taken three seek bar controls. From three Seekbar which Seekbar value changed the background color of device will be changed.

