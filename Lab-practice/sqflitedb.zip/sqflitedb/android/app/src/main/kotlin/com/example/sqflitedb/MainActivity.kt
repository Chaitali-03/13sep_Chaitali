package com.example.sqflitedb

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
