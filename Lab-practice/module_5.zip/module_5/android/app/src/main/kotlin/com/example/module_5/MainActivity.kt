package com.example.module_5

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
