class Task {
  int? id;
  String name;
  String description;
  DateTime date;
  String time;
  int priority; // 1: High, 2: Average, 3: Low

  Task({
    this.id,
    required this.name,
    required this.description,
    required this.date,
    required this.time,
    required this.priority,
  });
}
