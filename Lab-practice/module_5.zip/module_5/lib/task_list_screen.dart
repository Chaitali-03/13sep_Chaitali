import 'package:flutter/material.dart';

import 'addtask.dart';
import 'database_helper.dart';
import 'model.dart';

class TaskListScreen extends StatefulWidget {
  @override
  _TaskListScreenState createState() => _TaskListScreenState();
}

class _TaskListScreenState extends State<TaskListScreen> {
  late List<Task> tasks = [];
  late DatabaseHelper databaseHelper;

  @override
  void initState() {
    super.initState();
    databaseHelper = DatabaseHelper();
    refreshTaskList();
  }

  void refreshTaskList() async {
    List<Task> _tasks = await databaseHelper.getTasks();
    setState(() {
      tasks = _tasks;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Task List'),
      ),
      body: ListView.builder(
        itemCount: tasks.length,
        itemBuilder: (context, index) {
          return ListTile(
            title: Text(tasks[index].name),
            subtitle: Text(tasks[index].description),
            // Add more UI elements like date, time, priority, etc.
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          MaterialPageRoute(builder: (context) => AddTaskScreen());
        },
        child: Icon(Icons.add),
      ),
    );
  }
}