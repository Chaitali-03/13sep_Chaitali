import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import 'model.dart';

class DatabaseHelper {
  late Database _database;

  static final tabletask = 'tasks';

  static final columnId = '_id';
  static final columnname = 'name';
  static final columndescription = 'description';
  static final columndate = 'date';
  static final columntime = 'time';
  static final columnpriority = 'priority';

  Future<void> initializeDatabase() async {
    String path = await getDatabasesPath();
    String dbPath = join(path, 'tasks.db');

    _database = await openDatabase(
      dbPath,
      version: 1,
      onCreate: (db, version) {
        db.execute('''
          CREATE TABLE $tabletask(
              $columnId INTEGER PRIMARY KEY,
              $columnname TEXT,
              $columndescription TEXT, 
              $columndate TEXT, 
              $columntime TEXT, 
              $columnpriority INTEGER
              ),
        ''');
      },
    );
  }

  Future<List<Task>> getTasks() async {
    if (_database == null) {
      await initializeDatabase();
    }
    List<Map<String, dynamic>> taskMapList = await _database.query('tasks');
    List<Task> tasks = [];
    taskMapList.forEach((taskMap) {
      tasks.add(Task(
        id: taskMap['id'],
        name: taskMap['name'],
        description: taskMap['description'],
        date: DateTime.parse(taskMap['date']),
        time: taskMap['time'],
        priority: taskMap['priority'],
      ));
    });
    return tasks;
  }

// Add methods for adding, updating, deleting tasks
}
