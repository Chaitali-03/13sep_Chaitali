package com.example.musicbutten

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
