import 'package:flutter/material.dart';
import 'package:sqflite/sqflite.dart';

enum Priority { Low, Medium, High }

class Task {
  final int id;
  final String name;
  final String description;
  final DateTime date;
  final TimeOfDay time;
  final Priority priority;
  bool completed;

  Task({
    required this.id,
    required this.name,
    required this.description,
    required this.date,
    required this.time,
    required this.priority,
    this.completed = false,
  });
  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'name': name,
      'description': description,
      'date': date.toIso8601String(), // Convert DateTime to ISO 8601 format
      'time': '${time.hour}:${time.minute}',
      'priority': priority.index,
      'completed': completed ? 1 : 0,
    };
  }
}
