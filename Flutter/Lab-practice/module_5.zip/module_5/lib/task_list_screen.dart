import 'package:flutter/material.dart';
import 'package:module_5/database_helper.dart';
import 'package:module_5/model.dart';

import 'addtask.dart';

class TaskListScreen extends StatefulWidget {
  @override
  _TaskListScreenState createState() => _TaskListScreenState();
}

class _TaskListScreenState extends State<TaskListScreen> {
  DateTime? _selectedDate;
  late Future<List<Task>> _taskListFuture;
  TextEditingController _searchController = TextEditingController();
  List<Task> _filteredTasks = [];


  @override
  void initState() {
    super.initState();
    _taskListFuture = DatabaseHelper.instance.retrieveTasks();
  }

  void _markTaskAsCompleted(Task task) async {
    // Update task status to indicate completion
    task.completed = true;
    await DatabaseHelper.instance.updateTask(task);

    // Refresh task list
    setState(() {
      _taskListFuture = DatabaseHelper.instance.retrieveTasks();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
     appBar:AppBar(
        title: Text('Task List'),
        actions: [
          IconButton(
            onPressed: () async {
              final pickedDate = await showDatePicker(
                context: context,
                initialDate: DateTime.now(),
                firstDate: DateTime(2000),
                lastDate: DateTime(2100),
              );
              if (pickedDate != null) {
                setState(() {
                  _selectedDate = pickedDate;
                });
              }
            },
            icon: Icon(Icons.calendar_today),
          ),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: TextField(
              controller: _searchController,
              onChanged: _searchTasks,
              decoration: InputDecoration(
                hintText: 'Search tasks by name',
                prefixIcon: Icon(Icons.search),
              ),
            ),
          ),
          Expanded(
            child: FutureBuilder<List<Task>>(
              future: _taskListFuture,
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return Center(child: CircularProgressIndicator());
                } else if (snapshot.hasData) {
                  _filteredTasks = snapshot.data!;
                  return ListView.builder(
                    itemCount: _filteredTasks.length,
                    itemBuilder: (context, index) {
                      Task task = _filteredTasks[index];
                      bool isTaskDue = task.date.isBefore(DateTime.now());
                      Color priorityColor;
                      switch (task.priority) {
                        case Priority.High:
                          priorityColor = Colors.red;
                          break;
                        case Priority.Medium:
                          priorityColor = Colors.blue;
                          break;
                        case Priority.Low:
                          priorityColor = Colors.green;
                          break;
                      }
                      TextStyle textStyle = TextStyle(
                        color: isTaskDue ? Colors.blue : Colors.black,
                        decoration: task.completed ? TextDecoration.lineThrough : null,
                      );
                      return ListTile(
                        title: Text(
                          task.name,
                          style: textStyle,
                        ),
                        subtitle: Text(
                          task.description,
                          style: textStyle,
                        ),
                        tileColor: priorityColor.withOpacity(0.3),
                        onTap: () {
                          showTaskContextMenu(context, task);
                        },
                      );
                    },
                  );
                } else {
                  return Center(child: Text('No tasks found'));
                }
              },
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => AddTaskScreen()),
          );
        },
        child: Icon(Icons.add),
      ),
    );
  }
  void _searchTasks(String query) {
    setState(() {
      _filteredTasks = _filteredTasks.where((task) => task.name.toLowerCase().contains(query.toLowerCase())).toList();
    });
  }
  void showTaskContextMenu(BuildContext context, Task task) {
    final RenderBox overlay = Overlay.of(context).context.findRenderObject() as RenderBox;
    final RenderBox item = context.findRenderObject() as RenderBox;
    final Offset target = item.localToGlobal(Offset.zero, ancestor: overlay);

    final List<PopupMenuItem<String>> items = <PopupMenuItem<String>>[
      PopupMenuItem<String>(
        value: 'complete',
        child: Text('Complete the Task'),
      ),
    ];

    showMenu<String>(
      context: context,
      position: RelativeRect.fromLTRB(target.dx, target.dy, target.dx + item.size.width, target.dy + item.size.height),
      items: items,
    ).then<void>((String? value) {
      if (value == 'complete') {
        _markTaskAsCompleted(task);
      }
    });
  }
}
