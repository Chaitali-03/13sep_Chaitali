import 'package:flutter/material.dart';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import 'model.dart';

class DatabaseHelper {
  static final _databaseName = "task_database.db";
  static final _databaseVersion = 1;



  static final table = 'task';
  static final columnId = 'id';
  static final columnName = 'name';
  static final columnDescription = 'description';
  static final columnDate = 'date';
  static final columnTime = 'time';
  static final columnPriority = 'priority';

  DatabaseHelper._privateConstructor();
  static final DatabaseHelper instance = DatabaseHelper._privateConstructor();

  late Database _database;

  Future<Database> get database async {
    if (_database != null) return _database;
    _database = await _initDatabase();
    return _database;
  }

  Future<void> initializeDatabase() async {
    _database = await _initDatabase();
  }

  Future<Database> _initDatabase() async {
    String path = join(await getDatabasesPath(), _databaseName);
    return await openDatabase(path, version: _databaseVersion, onCreate: _onCreate);
  }

  Future<void> _onCreate(Database db, int version) async {
    await db.execute('''
      CREATE TABLE $table (
        $columnId INTEGER PRIMARY KEY,
        $columnName TEXT NOT NULL,
        $columnDescription TEXT NOT NULL,
        $columnDate TEXT NOT NULL,
        $columnTime TEXT NOT NULL,
        $columnPriority TEXT NOT NULL,
        completed INTEGER NOT NULL DEFAULT 0
      )
    ''');
  }

  Future<int> insertTask(Task task) async {
    Database db = await instance.database;
    return await db.insert('task', task.toMap());
  }

  Future<List<Task>> retrieveTasks() async {
    final Database db = await instance.database;
    final List<Map<String, dynamic>> maps = await db.query(
      'task',
      orderBy: '$columnDate ASC, $columnTime ASC', // Sort by date and time in ascending order
    );
    return List.generate(maps.length, (i) {
      return Task(
        id: maps[i][columnId],
        name: maps[i][columnName],
        description: maps[i][columnDescription],
        date: DateTime.parse(maps[i][columnDate]),
        time: TimeOfDay(
          hour: int.parse(maps[i][columnTime].split(':')[0]),
          minute: int.parse(maps[i][columnTime].split(':')[1]),
        ),
        priority: Priority.values.firstWhere(
                (e) => e.toString().split('.').last == maps[i][columnPriority]),
      );
    });
  }


  Future<int> updateTask(Task task) async {
    Database db = await instance.database;
    return await db.update(
      'task',
      task.toMap(),
      where: '$columnId = ?',
      whereArgs: [task.id],
    );
  }

  Future<int> deleteTask(int id) async {
    Database db = await instance.database;
    return await db.delete(
      'task',
      where: '$columnId = ?',
      whereArgs: [id],
    );
  }
}
