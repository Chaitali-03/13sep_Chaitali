import 'package:flutter/material.dart';
import 'package:module_5/database_helper.dart';
import 'package:module_5/model.dart';

class AddTaskScreen extends StatefulWidget {
  @override
  _AddTaskScreenState createState() => _AddTaskScreenState();
}

class _AddTaskScreenState extends State<AddTaskScreen> {
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _descriptionController = TextEditingController();
  late DatabaseHelper db;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();

    db = DatabaseHelper.instance;
    // Ensure that the database is initialized
    db.initializeDatabase().then((_)
    {
      print('Database initialized');
    });

  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Add Task')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            TextField(
              controller: _nameController,
              decoration: InputDecoration(labelText: 'Task Name'),
            ),
            TextField(
              controller: _descriptionController,
              decoration: InputDecoration(labelText: 'Description'),
            ),
            ElevatedButton(
              onPressed: () async {
                Task task = Task(
                  id: 1, // You may want to generate an actual ID
                  name: _nameController.text,
                  description: _descriptionController.text,
                  date: DateTime.now(),
                  time: TimeOfDay.now(),
                  priority: Priority.Low,
                );
                int taskId = await db.insertTask(task);
                print("aaa $taskId");
                Navigator.pop(context); // Go back to previous screen
              },
              child: Text('Add Task'),
            ),
          ],
        ),
      ),
    );
  }
}
