package com.example.uploadimage

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
