class Model
{

  late String image;
  late String title;
  late String subtitle1;
  late String subtitle2;
  Model({

    required this.image,
    required this.title,
    required this.subtitle1,
    required this.subtitle2
  });

}