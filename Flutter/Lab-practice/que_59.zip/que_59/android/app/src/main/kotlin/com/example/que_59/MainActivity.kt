package com.example.que_59

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
