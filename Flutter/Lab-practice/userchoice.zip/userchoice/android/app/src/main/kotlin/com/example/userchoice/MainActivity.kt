package com.example.userchoice

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
