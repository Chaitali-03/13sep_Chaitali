package com.example.fromcreat

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
