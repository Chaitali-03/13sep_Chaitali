package com.example.apicalling

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
