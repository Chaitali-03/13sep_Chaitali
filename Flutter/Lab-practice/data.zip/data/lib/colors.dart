import 'package:flutter/cupertino.dart';

class MyColors {
  static const primaryColor = Color(0xff00bf8e);
  static const orangeTile = Color(0xffffe1bb);
  static const orangeDivider = Color(0xffffc77e);
  static const contactDivider = Color(0xff89cdbb);
  static const drawalDivider = Color(0xff385cd8);
  static const drawalBackground = Color(0xff141414);
}