package com.example.data

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
