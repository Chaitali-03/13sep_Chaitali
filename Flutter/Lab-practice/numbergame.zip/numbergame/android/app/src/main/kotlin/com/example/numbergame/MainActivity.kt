package com.example.numbergame

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
