package com.example.jsoncrud

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
