package com.example.imagechanging

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
