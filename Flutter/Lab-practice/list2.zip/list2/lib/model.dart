class Model
{

  late String title;
  late String subtitle1;
  late String subtitle2;
  late String subtitle3;
  late String image;
  late String icon;
  Model({

    required this.title,
    required this.subtitle1,
    required this.subtitle2,
    required this.subtitle3,
    required this.image,
    required this.icon
  });

}