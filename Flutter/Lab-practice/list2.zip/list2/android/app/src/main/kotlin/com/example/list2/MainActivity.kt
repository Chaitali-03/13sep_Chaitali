package com.example.list2

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
