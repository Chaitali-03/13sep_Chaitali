package com.example.que_51

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
