package com.example.que_54

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
