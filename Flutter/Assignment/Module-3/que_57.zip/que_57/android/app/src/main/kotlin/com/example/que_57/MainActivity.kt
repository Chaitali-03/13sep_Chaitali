package com.example.que_57

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
