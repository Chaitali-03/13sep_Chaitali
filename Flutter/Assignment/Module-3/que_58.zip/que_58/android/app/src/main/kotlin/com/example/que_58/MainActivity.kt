package com.example.que_58

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
