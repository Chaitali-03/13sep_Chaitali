package com.example.que_60

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
