import 'package:flutter/material.dart';

const Color White = Color(0xFFF5F5F5);
const Color Orange = Color(0xFFFDB730);
