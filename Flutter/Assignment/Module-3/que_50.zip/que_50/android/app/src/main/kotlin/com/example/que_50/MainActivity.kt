package com.example.que_50

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
