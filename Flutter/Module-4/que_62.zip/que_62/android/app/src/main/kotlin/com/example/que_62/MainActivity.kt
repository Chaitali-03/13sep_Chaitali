package com.example.que_62

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
