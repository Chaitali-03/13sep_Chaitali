package com.example.que_55

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
