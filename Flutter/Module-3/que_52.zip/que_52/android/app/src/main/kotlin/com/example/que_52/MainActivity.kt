package com.example.que_52

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
