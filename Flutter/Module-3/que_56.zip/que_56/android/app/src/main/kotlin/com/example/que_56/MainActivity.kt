package com.example.que_56

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
